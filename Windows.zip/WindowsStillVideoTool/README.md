# App Store 静态预览视频工具

这个工具用于把一张图片制作成 App Store 预览视频风格的 MP4。

## 输出标准

- 格式：MP4
- 视频：H.264
- 音频：AAC 静音立体声轨
- 帧率：30fps
- 尺寸：保持原图尺寸
- 默认时长：25 秒
- 默认大小：450MB
- 画面：全程静态展示同一张图片

## 使用方式

1. 双击运行 `StillVideoMaker.pyw`。
2. 选择图片。
3. 输入视频秒数和目标大小。
4. 点击“开始制作”。
5. 如果本地没有 `ffmpeg.exe`，工具会首次自动下载；以后不会重复下载。

## ffmpeg.exe

工具需要 `ffmpeg.exe` 来编码视频，但不用你手动准备。

工具启动制作时会按顺序检查：

1. 工具同目录是否已有 `ffmpeg.exe`
2. 本地缓存目录是否已有 `ffmpeg.exe`
3. Windows PATH 里是否已有 FFmpeg

如果都没有，才会自动下载一次。

下载源：

```text
https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
```

只要你不删除已下载的 `ffmpeg.exe`，后续不会重复下载。

## 打包 EXE

双击：

```text
build_exe.bat
```

打包完成后，EXE 在：

```text
dist\StillVideoMaker.exe
```

打包后也一样：如果同目录或缓存里已有 `ffmpeg.exe`，就不会重复下载。

## 说明

工具会先生成标准 H.264 + 静音 AAC 的 MP4，再写入合法 MP4 `free` box 补到目标大小。这个标准对应已经测试通过的文件：

```text
im视频制作尺寸6.5_AppStore_H264_SilentAAC_450M.mp4
```
