import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
import urllib.request
import zipfile
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional, Tuple


APP_TITLE = "App Store 静态预览视频工具"
DEFAULT_SECONDS = "25"
DEFAULT_SIZE_MB = "450"
OUTPUT_FORMAT = "mp4"
FFMPEG_ZIP_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def find_ffmpeg() -> Optional[str]:
    local = app_dir() / "ffmpeg.exe"
    if local.exists():
        return str(local)
    cached = ffmpeg_cache_dir() / "ffmpeg.exe"
    if cached.exists():
        return str(cached)
    return shutil.which("ffmpeg.exe") or shutil.which("ffmpeg")


def ffmpeg_cache_dir() -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "StillVideoMaker"
    return app_dir() / "ffmpeg-cache"


def ffmpeg_install_dir() -> Path:
    probe = app_dir() / ".write_test"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return app_dir()
    except Exception:
        return ffmpeg_cache_dir()


def ensure_ffmpeg(status_callback) -> str:
    found = find_ffmpeg()
    if found:
        return found

    install_dir = ffmpeg_install_dir()
    install_dir.mkdir(parents=True, exist_ok=True)
    target = install_dir / "ffmpeg.exe"

    with tempfile.TemporaryDirectory(prefix="ffmpeg_download_") as temp_dir:
        zip_path = Path(temp_dir) / "ffmpeg-release-essentials.zip"
        status_callback("未找到 ffmpeg.exe，首次运行正在下载 FFmpeg...")
        with urllib.request.urlopen(FFMPEG_ZIP_URL, timeout=60) as response, zip_path.open("wb") as handle:
            total = int(response.headers.get("Content-Length", "0") or 0)
            downloaded = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                downloaded += len(chunk)
                if total:
                    status_callback(f"正在下载 FFmpeg：{downloaded / total * 100:.1f}%")
                else:
                    status_callback(f"正在下载 FFmpeg：{downloaded / 1024 / 1024:.1f} MB")

        status_callback("正在解压 ffmpeg.exe...")
        with zipfile.ZipFile(zip_path) as archive:
            ffmpeg_member = None
            for name in archive.namelist():
                normalized = name.replace("\\", "/").lower()
                if normalized.endswith("/bin/ffmpeg.exe"):
                    ffmpeg_member = name
                    break
            if not ffmpeg_member:
                raise RuntimeError("下载包中没有找到 ffmpeg.exe。")
            with archive.open(ffmpeg_member) as source, target.open("wb") as destination:
                shutil.copyfileobj(source, destination)

    status_callback(f"FFmpeg 已安装：{target}")
    return str(target)


def append_mp4_free_box(path: Path, target_bytes: int) -> int:
    current_size = path.stat().st_size
    if current_size > target_bytes:
        raise ValueError(f"基础视频已是 {current_size / 1024 / 1024:.1f} MB，大于目标大小。")
    if target_bytes - current_size < 8:
        return current_size

    free_box_size = target_bytes - current_size
    if free_box_size > 0xFFFFFFFF:
        raise ValueError("目标大小过大，单个 MP4 free box 不能超过 4GB。")

    chunk = b"\0" * (1024 * 1024)
    with path.open("ab") as handle:
        handle.write(struct.pack(">I4s", free_box_size, b"free"))
        remaining = free_box_size - 8
        while remaining > 0:
            count = min(remaining, len(chunk))
            handle.write(chunk[:count])
            remaining -= count

    return path.stat().st_size


def run_ffmpeg_still_preview(
    ffmpeg: str,
    image_path: Path,
    output_path: Path,
    seconds: float,
    target_mb: float,
) -> Tuple[int, int]:
    target_bytes = int(target_mb * 1024 * 1024)
    if target_bytes < 10 * 1024 * 1024:
        raise ValueError("目标大小太小，建议至少 10MB。")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="appstore_preview_") as temp_dir:
        base_output = Path(temp_dir) / "base_preview.mp4"
        command = [
            ffmpeg,
            "-y",
            "-loop",
            "1",
            "-framerate",
            "30",
            "-t",
            str(seconds),
            "-i",
            str(image_path),
            "-f",
            "lavfi",
            "-t",
            str(seconds),
            "-i",
            "anullsrc=channel_layout=stereo:sample_rate=44100",
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-shortest",
            "-c:v",
            "libx264",
            "-profile:v",
            "high",
            "-level:v",
            "4.0",
            "-preset",
            "veryfast",
            "-tune",
            "stillimage",
            "-pix_fmt",
            "yuv420p",
            "-r",
            "30",
            "-b:v",
            "12M",
            "-c:a",
            "aac",
            "-b:a",
            "256k",
            "-ar",
            "44100",
            "-ac",
            "2",
            "-movflags",
            "+faststart",
            str(base_output),
        ]
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr.strip() or "ffmpeg 生成失败。")

        shutil.copy2(base_output, output_path)

    base_size = output_path.stat().st_size
    final_size = append_mp4_free_box(output_path, target_bytes)
    return base_size, final_size


class PreviewTool(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("680x430")
        self.minsize(640, 420)
        self.configure(bg="#f4f7fb")

        self.image_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.seconds_var = tk.StringVar(value=DEFAULT_SECONDS)
        self.size_var = tk.StringVar(value=DEFAULT_SIZE_MB)
        self.status_var = tk.StringVar(value="请选择图片，默认生成 25 秒、450MB、MP4。")
        self.ffmpeg = find_ffmpeg()

        self.build_ui()

    def build_ui(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#f4f7fb")
        style.configure("Title.TLabel", background="#f4f7fb", foreground="#132033", font=("Microsoft YaHei UI", 18, "bold"))
        style.configure("TLabel", background="#f4f7fb", foreground="#243447", font=("Microsoft YaHei UI", 10))
        style.configure("Hint.TLabel", background="#f4f7fb", foreground="#6d7f92", font=("Microsoft YaHei UI", 9))
        style.configure("TButton", font=("Microsoft YaHei UI", 10))
        style.configure("Primary.TButton", font=("Microsoft YaHei UI", 12, "bold"), padding=10)

        root = ttk.Frame(self, padding=22)
        root.pack(fill="both", expand=True)

        ttk.Label(root, text="App Store 静态预览视频工具", style="Title.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(
            root,
            text="标准输出：原图尺寸、H.264 MP4、静音 AAC 音频轨、30fps，并补到指定 MB。",
            style="Hint.TLabel",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(4, 18))

        self.add_file_row(root, 2, "图片文件", self.image_var, self.choose_image)
        self.add_file_row(root, 3, "输出 MP4", self.output_var, self.choose_output)

        ttk.Label(root, text="视频时长（秒）").grid(row=4, column=0, sticky="w", pady=(14, 4))
        ttk.Entry(root, textvariable=self.seconds_var).grid(row=4, column=1, sticky="ew", pady=(14, 4))

        ttk.Label(root, text="目标大小（MB）").grid(row=5, column=0, sticky="w", pady=4)
        ttk.Entry(root, textvariable=self.size_var).grid(row=5, column=1, sticky="ew", pady=4)

        ttk.Label(root, text="视频格式").grid(row=6, column=0, sticky="w", pady=4)
        ttk.Label(root, text="MP4 / H.264 / 静音 AAC", style="Hint.TLabel").grid(row=6, column=1, sticky="w", pady=4)

        self.ffmpeg_label = ttk.Label(root, text=self.ffmpeg_status_text(), style="Hint.TLabel")
        self.ffmpeg_label.grid(row=7, column=0, columnspan=3, sticky="w", pady=(12, 2))

        ttk.Label(
            root,
            text="提示：如果目标大小 400-500M，建议时长 25 秒、大小 450MB。",
            style="Hint.TLabel",
        ).grid(row=8, column=0, columnspan=3, sticky="w", pady=(0, 16))

        self.make_button = ttk.Button(root, text="开始制作", style="Primary.TButton", command=self.start_make)
        self.make_button.grid(row=9, column=0, columnspan=3, sticky="ew")

        ttk.Label(root, textvariable=self.status_var, style="Hint.TLabel", wraplength=620).grid(row=10, column=0, columnspan=3, sticky="w", pady=(18, 0))
        root.columnconfigure(1, weight=1)

    def add_file_row(self, parent: ttk.Frame, row: int, label: str, variable: tk.StringVar, command) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=(0, 8), pady=6)
        ttk.Button(parent, text="选择", command=command).grid(row=row, column=2, sticky="e", pady=6)

    def ffmpeg_status_text(self) -> str:
        if self.ffmpeg:
            return f"ffmpeg：已找到 {self.ffmpeg}"
        return "ffmpeg：未找到，首次制作时会自动下载一次。"

    def choose_image(self) -> None:
        path = filedialog.askopenfilename(
            title="选择图片",
            filetypes=[
                ("图片文件", "*.png;*.jpg;*.jpeg;*.bmp;*.webp"),
                ("所有文件", "*.*"),
            ],
        )
        if not path:
            return
        self.image_var.set(path)
        if not self.output_var.get():
            self.output_var.set(str(Path(path).with_suffix(".mp4")))

    def choose_output(self) -> None:
        path = filedialog.asksaveasfilename(
            title="保存 MP4",
            defaultextension=".mp4",
            filetypes=[("MP4 视频", "*.mp4")],
        )
        if path:
            self.output_var.set(path)

    def validate_inputs(self) -> Tuple[Path, Path, float, float]:
        image = Path(self.image_var.get().strip())
        output = Path(self.output_var.get().strip())

        if not image.exists():
            raise ValueError("请选择有效图片。")
        if not output:
            raise ValueError("请选择输出位置。")
        if output.suffix.lower() != ".mp4":
            output = output.with_suffix(".mp4")
            self.output_var.set(str(output))

        seconds = float(self.seconds_var.get().strip())
        target_mb = float(self.size_var.get().strip())
        if seconds <= 0:
            raise ValueError("视频时长必须大于 0 秒。")
        if target_mb <= 0:
            raise ValueError("目标大小必须大于 0 MB。")
        return image, output, seconds, target_mb

    def start_make(self) -> None:
        self.ffmpeg = find_ffmpeg()
        self.ffmpeg_label.configure(text=self.ffmpeg_status_text())

        try:
            image, output, seconds, target_mb = self.validate_inputs()
        except Exception as error:
            messagebox.showerror("参数错误", str(error))
            return

        self.make_button.configure(state="disabled")
        self.status_var.set("正在制作，请稍等...")
        threading.Thread(target=self.worker, args=(image, output, seconds, target_mb), daemon=True).start()

    def worker(self, image: Path, output: Path, seconds: float, target_mb: float) -> None:
        try:
            self.ffmpeg = ensure_ffmpeg(self.thread_status)
            self.after(0, lambda: self.ffmpeg_label.configure(text=self.ffmpeg_status_text()))
            base, final = run_ffmpeg_still_preview(self.ffmpeg, image, output, seconds, target_mb)
            message = (
                f"制作完成：{output}\n"
                f"基础视频：{base / 1024 / 1024:.1f} MB，最终大小：{final / 1024 / 1024:.1f} MB\n"
                f"格式：MP4 / H.264 / 静音 AAC"
            )
            self.after(0, lambda: self.done(True, message))
        except Exception as error:
            self.after(0, lambda: self.done(False, str(error)))

    def thread_status(self, message: str) -> None:
        self.after(0, lambda: self.status_var.set(message))

    def done(self, success: bool, message: str) -> None:
        self.make_button.configure(state="normal")
        self.status_var.set(message)
        if success:
            messagebox.showinfo("完成", message)
        else:
            messagebox.showerror("制作失败", message)


if __name__ == "__main__":
    PreviewTool().mainloop()
