@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo 正在安装/检查 PyInstaller...
python -m pip install pyinstaller
if errorlevel 1 (
    echo.
    echo PyInstaller 安装失败，请确认 Windows 已安装 Python，并且 pip 可用。
    pause
    exit /b 1
)

echo.
echo 正在打包 StillVideoMaker.exe...
python -m PyInstaller ^
  --noconsole ^
  --onefile ^
  --name StillVideoMaker ^
  StillVideoMaker.pyw

if errorlevel 1 (
    echo.
    echo 打包失败。
    pause
    exit /b 1
)

echo.
echo 打包完成：dist\StillVideoMaker.exe
echo 如果需要免配置运行，请把 ffmpeg.exe 放到 dist\StillVideoMaker.exe 同目录。
pause
